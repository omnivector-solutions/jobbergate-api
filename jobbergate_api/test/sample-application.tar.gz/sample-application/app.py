import os
import subprocess
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from jobbergate_cli import appform, workflow # workflow needed?
from jobbergate_cli.application_base import JobbergateApplicationBase
from jobbergate_cli.jobberappslib import get_running_jobs, get_file_list



# cory

class JobbergateApplication(JobbergateApplicationBase):
    #     self.jobbergate_config = jobbergate_yaml['jobbergate_config']
    #     self.application_config = jobbergate_yaml['application_config']

    def mainflow(self, data):
        questions = []

        questions.append(appform.List(
            "cluster",
            message="Choose which cluster to build script for",
            choices=[
                ("Nash (Scania)", "Nash"),
                ("Beskow (KTH)", "Beskow")]
        ))

        questions.append(appform.List(
            "nextworkflow",
            message="Select simulation task",
            choices=[
                ("Simulate", "Sim"),
                ("Mesh serial", "Mesh")
            ]
        ))

        return questions


    def Sim(self, data):
        questions = []
        print("in Sim")
        questions.append(appform.Integer(
            "simsteps",
            message="Set amount of steps",
            default=100
        ))
        data["nextworkflow"] = "wrapup"
        return questions


    def Mesh(self, data):
        questions = []
        print("in Mesh")
        questions.append(appform.Integer(
            "memory",
            message="Needed memory [GB]",
            default=210
        ))
        data["nextworkflow"] = "wrapup"
        return questions


    def wrapup(self, data):
        questions = []
        print("in wrapup")
        questions.append(appform.Confirm(
            "stageup",
            message="Stage files to cluster disk?",
            default=False
        ))
        return questions
